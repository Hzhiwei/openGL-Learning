
#include "GLShader.h"

GLShaderProgram::GLShaderProgram()
{
	ProgramID = glCreateProgram();
}

GLShaderProgram::GLShaderProgram(GLuint Vertex, GLuint Fragment)
{
	ProgramID = glCreateProgram();
	SetShader(Vertex, Fragment);
}


GLShaderProgram::~GLShaderProgram()
{
}

void GLShaderProgram::SetVertexShader(GLuint Vertex)
{
	VertexShaderID = Vertex;
	glAttachShader(ProgramID, VertexShaderID);
}

void GLShaderProgram::SetFragmentShader(GLuint Fragment)
{
	FragmentShaderID = Fragment;
	glAttachShader(ProgramID, FragmentShaderID);
}

void GLShaderProgram::SetShader(GLuint Vertex, GLuint Fragment)
{
	VertexShaderID = Vertex;
	FragmentShaderID = Fragment;
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
}

bool GLShaderProgram::Link()
{
	GLint success;
	glLinkProgram(ProgramID);
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &success);
	if (!success)
	{
		return false;
	}
	else
	{
		return true;
	}
}

std::string GLShaderProgram::GetLinkInfo()
{
	glGetProgramInfoLog(ProgramID, INFOLENGTH, NULL, Info);
	return std::string(Info);
}

void GLShaderProgram::Use()
{
	glUseProgram(ProgramID);
}

void GLShaderProgram::SetBool(const std::string & Name, bool value) const
{
	glUniform1i(glGetUniformLocation(ProgramID, Name.c_str()), (int)value);
}

void GLShaderProgram::SetInt(const std::string & Name, int value) const
{
	glUniform1i(glGetUniformLocation(ProgramID, Name.c_str()), value);
}

void GLShaderProgram::SetFloat(const std::string & Name, float value) const
{
	glUniform1f(glGetUniformLocation(ProgramID, Name.c_str()), value);
}

void GLShaderProgram::SetMat4fv(const std::string & Name, const GLfloat *value) const
{
	glUniformMatrix4fv(glGetUniformLocation(ProgramID, Name.c_str()), 1, GL_FALSE, value);
}


ShaderFileSource::ShaderFileSource()
{
}

ShaderFileSource::ShaderFileSource(string Path)
{
	LoadFile(Path);
}


ShaderFileSource::~ShaderFileSource()
{
}

bool ShaderFileSource::LoadFile(string Path)
{
	ifstream str(Path);

	if (!str.is_open())
	{
		return false;
	}

	FunctionAnalyze(str);

	str.close();

	return false;
}

bool ShaderFileSource::SetHeader(string Head)
{
	if ((Head == "") || (Head == header))
	{
		return false;
	}
	else
	{
		header = Head;
		return true;
	}
}

bool ShaderFileSource::SetEnder(string End)
{
	if ((End == "") || (End == ender))
	{
		return false;
	}
	else
	{
		ender = End;
		return true;
	}
}

std::string ShaderFileSource::GetShaderCode(string Name)
{
	map<string, string>::iterator itor = FunctionMap.find(Name);
	if (itor == FunctionMap.end())
	{
		return "";
	}
	else
	{
		return FunctionMap[Name];
	}
}

void ShaderFileSource::Clear()
{
	FunctionMap.clear();
}

void ShaderFileSource::FunctionAnalyze(ifstream &stream)
{
	string line, key, source;

	FunctionMap.clear();

	while (true)
	{
		if (!getline(stream, line))
			//end of file
		{
			break;
		}

		int headerStartInLine = line.find(header);

		if (headerStartInLine != string::npos)
			//found header
		{
			string temp = line.substr(headerStartInLine + header.length());
			key = "";
			for (int i = 0; i < temp.length(); ++i)
			{
				if (temp[i] != ' ')
				{
					key += temp[i];
				}
			}

			source = "";
			while (true)
			{
				if (!getline(stream, line))
					//end of file
				{
					break;
				}

				if (line.find(ender) != string::npos)
					//found ender
				{
					FunctionMap[key] = source;
					break;
				}
				else
					// contious source code
				{
					source = source + '\n' + line;
				}
			}
		}
	}
}

