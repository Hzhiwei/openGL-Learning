#include "SHaderFileSource.h"



ShaderFileSource::ShaderFileSource()
{
}

ShaderFileSource::ShaderFileSource(string Path)
{
	LoadFile(Path);
}


ShaderFileSource::~ShaderFileSource()
{
}

bool ShaderFileSource::LoadFile(string Path)
{
	ifstream str(Path);

	if (!str.is_open())
	{
		return false;
	}

	FunctionAnalyze(str);

	str.close();

	return false;
}

bool ShaderFileSource::SetHeader(string Head)
{
	if ((Head == "") || (Head == header))
	{
		return false;
	}
	else
	{
		header = Head;
		return true;
	}
}

bool ShaderFileSource::SetEnder(string End)
{
	if ((End == "") || (End == ender))
	{
		return false;
	}
	else
	{
		ender = End;
		return true;
	}
}

std::string ShaderFileSource::GetShaderCode(string Name)
{
	map<string, string>::iterator itor = FunctionMap.find(Name);
	if (itor == FunctionMap.end())
	{
		return "";
	}
	else
	{
		return FunctionMap[Name];
	}
}

void ShaderFileSource::Clear()
{
	FunctionMap.clear();
}

void ShaderFileSource::FunctionAnalyze(ifstream &stream)
{
	string line, key, source;

	FunctionMap.clear();

	while (true)
	{
		if (!getline(stream, line))
			//end of file
		{
			break;
		}

		int headerStartInLine = line.find(header);

		if (headerStartInLine != string::npos)
			//found header
		{
			string temp = line.substr(headerStartInLine + header.length());
			key = "";
			for (int i = 0; i < temp.length(); ++i)
			{
				if (temp[i] != ' ')
				{
					key += temp[i];
				}
			}

			source = "";
			while (true)
			{
				if (!getline(stream, line))
					//end of file
				{
					break;
				}

				if (line.find(ender) != string::npos)
					//found ender
				{
					FunctionMap[key] = source;
					break;
				}
				else
					// contious source code
				{
					source = source + '\n' + line;
				}
			}
		}
	}
}
