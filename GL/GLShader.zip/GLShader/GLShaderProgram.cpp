#include "GLShaderProgram.h"



GLShaderProgram::GLShaderProgram()
{
	ProgramID = glCreateProgram();
}

GLShaderProgram::GLShaderProgram(GLuint Vertex, GLuint Fragment)
{
	ProgramID = glCreateProgram();
	SetShader(Vertex, Fragment);
}


GLShaderProgram::~GLShaderProgram()
{
}

void GLShaderProgram::SetVertexShader(GLuint Vertex)
{
	VertexShaderID = Vertex;
	glAttachShader(ProgramID, VertexShaderID);
}

void GLShaderProgram::SetFragmentShader(GLuint Fragment)
{
	FragmentShaderID = Fragment;
	glAttachShader(ProgramID, FragmentShaderID);
}

void GLShaderProgram::SetShader(GLuint Vertex, GLuint Fragment)
{
	VertexShaderID = Vertex;
	FragmentShaderID = Fragment;
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
}

bool GLShaderProgram::Link()
{
	GLint success;
	glLinkProgram(ProgramID);
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &success);
	if (!success)
	{
		return false;
	}
	else
	{
		return true;
	}
}

std::string GLShaderProgram::GetLinkInfo()
{
	glGetProgramInfoLog(ProgramID, INFOLENGTH, NULL, Info);
	return std::string(Info);
}

void GLShaderProgram::Use()
{
	glUseProgram(ProgramID);
}

void GLShaderProgram::SetBool(const std::string & Name, bool value) const
{
	glUniform1i(glGetUniformLocation(ProgramID, Name.c_str()), (int)value);
}

void GLShaderProgram::SetInt(const std::string & Name, bool value) const
{
	glUniform1i(glGetUniformLocation(ProgramID, Name.c_str()), value);
}

void GLShaderProgram::SetFloat(const std::string & Name, bool value) const
{
	glUniform1f(glGetUniformLocation(ProgramID, Name.c_str()), value);
}
