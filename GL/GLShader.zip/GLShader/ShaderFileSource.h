#pragma once

#include <map>
#include <string>
#include <iostream>
#include <fstream> 

using namespace std;

class ShaderFileSource
{
public:
	ShaderFileSource();
	ShaderFileSource(string Path);
	~ShaderFileSource();

	bool LoadFile(string Path);
	bool SetHeader(string Head);
	bool SetEnder(string End);
	std::string ShaderFileSource::GetShaderCode(string Name);
	void Clear();

private:
	void FunctionAnalyze(ifstream &stream);

private:
	string header = "##start";
	string ender = "##end";
	map<string, string> FunctionMap;
};

