#pragma once

#include "../GLAD/glad.h"
#include <string>


#define INFOLENGTH 1024


class GLShaderProgram
{
public:
	GLShaderProgram();
	GLShaderProgram(GLuint Vertex, GLuint Fragment);
	~GLShaderProgram();

	void SetVertexShader(GLuint Vertex);
	void SetFragmentShader(GLuint Fragment);
	void SetShader(GLuint Vertex, GLuint Fragment);
	bool Link();
	std::string GetLinkInfo();
	void Use();
	void SetBool(const std::string &name, bool value) const;
	void SetInt(const std::string &name, bool value) const;
	void SetFloat(const std::string &name, bool value) const;

private:
	GLuint ProgramID = 0;
	GLuint VertexShaderID =0;
	GLuint FragmentShaderID = 0;
	char Info[INFOLENGTH] = { 0 };
};

