#pragma once

#include "../GLAD/glad.h"
#include <iostream>
#include <string>
#include<stdexcept>


#define INFOLENGTH 1024


template<int ShaderType>
class GLShader
{
public:
	GLShader();
	GLShader(const GLchar * const Code);
	GLShader(const std::string &Code);
	~GLShader();

public:
	bool Source(const GLchar * const Code);
	bool Source(const std::string &Code);
	std::string GetCompileInfo();
	GLuint GetID();
	void Delete();

private:
	virtual void CreateShader();

protected:
	GLuint ID = 0;
	char Info[INFOLENGTH] = { 0 };
};


class ShaderTypeErrorException : public invalid_argument
{
public:
	explicit ShaderTypeErrorException(const std::string& what_arg) : invalid_argument(what_arg) {}
	explicit ShaderTypeErrorException(const char* what_arg) : invalid_argument(what_arg) {}
};


template<int ShaderType>
GLShader<ShaderType>::GLShader()
{
	if ((ShaderType != GL_VERTEX_SHADER) && (ShaderType != GL_FRAGMENT_SHADER))
	{
		throw ShaderTypeErrorException("Shader Type is Error!");
	}
	CreateShader();
}

template<int ShaderType>
GLShader<ShaderType>::GLShader(const GLchar * const Code)
{
	if ((ShaderType != GL_VERTEX_SHADER) && (ShaderType != GL_FRAGMENT_SHADER))
	{
		throw ShaderTypeErrorException("Shader Type is Error!");
	}
	CreateShader();
	Source(Code);
}

template<int ShaderType>
GLShader<ShaderType>::GLShader(const std::string & Code)
{
	if ((ShaderType != GL_VERTEX_SHADER) && (ShaderType != GL_FRAGMENT_SHADER))
	{
		throw ShaderTypeErrorException("Shader Type is Error!");
	}
	CreateShader();
	Source(Code);
}


template<int ShaderType>
GLShader<ShaderType>::~GLShader()
{
}

template<int ShaderType>
bool GLShader<ShaderType>::Source(GLchar const * const Code)
{
	int success;
	glShaderSource(ID, 1, &Code, NULL);
	glCompileShader(ID);
	glGetShaderiv(ID, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		return false;
	}
	else
	{
		return true;
	}
}

template<int ShaderType>
bool GLShader<ShaderType>::Source(const std::string & Code)
{
	return Source(Code.c_str());
}

template<int ShaderType>
std::string GLShader<ShaderType>::GetCompileInfo()
{
	glGetShaderInfoLog(ID, INFOLENGTH, NULL, Info);
	return std::string(Info);
}

template<int ShaderType>
GLuint GLShader<ShaderType>::GetID()
{
	return ID;
}

template<int ShaderType>
void GLShader<ShaderType>::Delete()
{
	glDeleteShader(ID);
}

template<int ShaderType>
void GLShader<ShaderType>::CreateShader()
{
	ID = glCreateShader(ShaderType);
}
